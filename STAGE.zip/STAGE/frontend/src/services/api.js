import axios from "axios";

const API_BASE_URL = "http://127.0.0.1:5004/api"; // URL de ton FastAPI

export const getCandidateRecommendations = async (candidateId) => {
  try {
    const response = await axios.get(
      `${API_BASE_URL}/recommendations/candidate/${candidateId}`
    );
    return response.data;
  } catch (error) {
    console.error(
      "❌ Erreur lors de la récupération des recommandations :",
      error
    );
    return null;
  }
};
