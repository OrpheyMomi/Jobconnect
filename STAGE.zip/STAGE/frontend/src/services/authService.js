import axios from "axios";

const API_URL = "http://127.0.0.1:5001/api/auth"; // Adresse du backend

const authService = {
  login: async (credentials) => {
    const response = await axios.post(`${API_URL}/login`, credentials);
    return response.data;
  },
  register: async (credentials) => {
    const response = await axios.post(`${API_URL}/register`, credentials);
    return response.data;
  },
  logout: () => {
    localStorage.removeItem("token");
  },
  getToken: () => localStorage.getItem("token"),
};

export default authService;
