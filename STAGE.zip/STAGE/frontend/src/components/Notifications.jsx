// Notifications.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
// Par exemple, si vous utilisez un contexte d'authentification :
import { useAuth } from "./AuthContext";

const Notifications = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    if (!user) return; // On attend que l'utilisateur soit défini

    // Important : la route GET doit correspondre à votre notificationRoutes
    // ex: GET /api/notifications/:userId
    axios
      .get(`http://127.0.0.1:5007/api/notifications/${user.id}`, {
        headers: { Authorization: `Bearer ${user.token}` },
      })
      .then((res) => {
        // Suppose qu'on renvoie { notifications: [...] } dans le backend
        setNotifications(res.data.notifications || []);
      })
      .catch((err) => {
        console.error("Erreur récupération notifications :", err);
      });
  }, [user]);

  return (
    <div className="max-w-4xl mx-auto p-6 bg-gray-50 min-h-screen">
      <h2 className="text-3xl font-bold mb-6 text-gray-800">
        Mes Notifications
      </h2>
      {notifications.length === 0 ? (
        <p className="text-gray-500">
          Vous n'avez aucune notification pour le moment.
        </p>
      ) : (
        <div className="space-y-4">
          {notifications.map((notif) => (
            <div
              key={notif._id}
              className="border border-gray-200 rounded-lg p-4 shadow-sm bg-white flex items-start gap-3"
            >
              {/* Icône "notification" stylisée */}
              <div className="p-2 rounded-full bg-blue-100 text-blue-600">
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M13 16h-1v-4h-1m1 0h1m-1-4h.01M21 12c0-4.418-3.582-8-8-8S5 7.582 5 12c0 3.533 2.29 6.532 5.466 7.592a1 1 0 01.534.908v.5a2 2 0 11-4 0v-.5a1 1 0 01.534-.908C5.29 18.532 3 15.533 3 12 3 6.477 7.477 2 13 2s10 4.477 10 10c0 3.533-2.29 6.532-5.466 7.592a1 1 0 01-.534.908v.5a2 2 0 11-4 0v-.5a1 1 0 01.534-.908C18.71 18.532 21 15.533 21 12z"
                  />
                </svg>
              </div>

              <div>
                <p className="font-medium text-gray-800">
                  {notif.title || "Notification"}
                </p>
                <p className="text-sm text-gray-600 mt-1">{notif.message}</p>
                {/* Afficher la date si dispo */}
                {notif.createdAt && (
                  <p className="text-xs text-gray-400 mt-2">
                    {new Date(notif.createdAt).toLocaleString()}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Notifications;
