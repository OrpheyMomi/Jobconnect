// src/components/Header.jsx
import React from "react";
import { Link } from "react-router-dom";
import { HomeIcon } from "@heroicons/react/24/outline";

const Header = ({ user }) => {
  return (
    <header className="bg-white shadow p-4 flex justify-between items-center ml-64">
      {/* Section gauche : icône maison + texte Accueil */}
      <div className="flex items-center gap-2">
        <HomeIcon className="w-6 h-6 text-blue-600" />
        <Link
          to="/dashboard"
          className="text-xl font-bold text-gray-800 hover:text-blue-600"
        >
          Accueil
        </Link>
      </div>

      {/* Section droite : Bonjour + Déconnexion */}
      <div>
        <span className="mr-4">
          Bonjour, {user?.email ? user.email.split("@")[0] : "Invité"}
        </span>
        <Link to="/logout" className="text-blue-500 hover:text-blue-700">
          Déconnexion
        </Link>
      </div>
    </header>
  );
};

export default Header;
