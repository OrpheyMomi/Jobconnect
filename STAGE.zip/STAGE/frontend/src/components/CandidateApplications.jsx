// src/components/CandidateApplications.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "./AuthContext"; // ✅ Importer le contexte

const CandidateApplications = () => {
  const { user, loading } = useAuth(); // ✅ Récupérer `user` depuis le contexte
  const [applications, setApplications] = useState([]);
  const [appLoading, setAppLoading] = useState(true);

  useEffect(() => {
    if (!user) return; // Empêcher la requête si user n'est pas défini

    axios
      .get(`http://127.0.0.1:5002/api/jobs/user/${user.id}/applications`, {
        headers: { Authorization: `Bearer ${user.token}` },
      })
      .then((res) => setApplications(res.data.applications || []))
      .catch((err) => console.error("Erreur récupération candidatures :", err))
      .finally(() => setAppLoading(false));
  }, [user]);

  if (loading || appLoading) return <div>Chargement des candidatures...</div>;
  if (!user) return <div>Veuillez vous connecter.</div>;

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-3xl font-bold mb-4">Mes Candidatures</h2>
      {applications.length === 0 ? (
        <p>Vous n'avez pas encore postulé à des offres.</p>
      ) : (
        <div className="space-y-4">
          {applications.map((app) => (
            <div key={app.id} className="border p-4 rounded">
              <h3 className="text-xl font-semibold">{app.jobDetails.title}</h3>
              <p className="text-gray-600">
                {app.jobDetails.company} – {app.jobDetails.location}
              </p>
              <p className="text-sm text-gray-500">Statut : {app.status}</p>
              <p className="text-sm text-gray-500">
                Date : {new Date(app.createdAt).toLocaleDateString()}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CandidateApplications;
