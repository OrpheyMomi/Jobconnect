// src/components/JobCard.jsx
import React from "react";
import { useNavigate } from "react-router-dom";
import { EyeIcon } from "@heroicons/react/24/solid"; // Assurez-vous d'avoir installé @heroicons/react

const JobCard = ({ job, alreadyApplied, user }) => {
  const navigate = useNavigate();

  if (!job) {
    return (
      <div className="p-4 text-gray-500">❌ Offre d'emploi introuvable.</div>
    );
  }

  const handleClick = () => {
    // On transmet user dans l'état pour que JobDetails puisse l'utiliser
    navigate(`/jobs/${job.id}`, { state: { user } });
  };

  return (
    <div className="bg-white border p-4 rounded-lg shadow-md hover:shadow-lg transition duration-300">
      <h3 className="text-xl font-semibold text-blue-600 mb-2">
        {job.title || "Titre non spécifié"}
      </h3>
      <p className="text-gray-800 font-medium mb-1">
        {job.company || "Entreprise inconnue"} –{" "}
        {job.location || "Localisation inconnue"}
      </p>
      <p className="text-gray-600 text-sm mb-2">
        {job.description || "Aucune description disponible."}
      </p>
      {job.salary !== undefined && (
        <p className="text-green-600 font-semibold mb-3">
          Salaire : {job.salary.toLocaleString()} € / an
        </p>
      )}
      <button
        onClick={handleClick}
        className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 w-full sm:w-auto transition duration-300 flex items-center justify-center gap-2"
      >
        {alreadyApplied ? (
          <>
            <EyeIcon className="w-5 h-5" />
            <span>Voir l'offre</span>
          </>
        ) : (
          <span>Voir l’offre & postuler</span>
        )}
      </button>
    </div>
  );
};

export default JobCard;
