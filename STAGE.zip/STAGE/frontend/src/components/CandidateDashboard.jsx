// src/components/CandidateDashboard.jsx
import { useEffect, useState } from "react";
import axios from "axios";
import JobCard from "./JobCard";

const CandidateDashboard = ({ user }) => {
  const [jobs, setJobs] = useState([]);
  const [recommendedJobs, setRecommendedJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [appliedJobs, setAppliedJobs] = useState([]); // Liste des jobIds déjà postulés

  const [showAllJobs, setShowAllJobs] = useState(false);
  const [searchWhat, setSearchWhat] = useState("");
  const [searchWhere, setSearchWhere] = useState("");

  useEffect(() => {
    // Récupération des offres
    axios
      .get("http://127.0.0.1:5002/api/jobs")
      .then((res) => {
        const allJobs = res.data.jobs || res.data || [];
        setJobs(allJobs);
      })
      .catch((err) => console.error("Erreur chargement jobs :", err));

    // Recommandations
    axios
      .get(`http://127.0.0.1:5004/api/recommendations/candidate/${user.id}`, {
        headers: { Authorization: `Bearer ${user.token}` },
      })
      .then((res) => {
        if (res.data.error) {
          setRecommendedJobs([]);
        } else {
          setRecommendedJobs(res.data.matches || []);
        }
      })
      .catch(() => {
        setRecommendedJobs([]);
      });
  }, [user.id, user.token]);

  // Récupération des candidatures déjà envoyées
  useEffect(() => {
    axios
      .get(`http://localhost:5002/api/jobs/user/${user.id}/applications`, {
        headers: { Authorization: `Bearer ${user.token}` },
      })
      .then((res) => {
        const apps = res.data.applications || [];
        const appliedIds = apps.map((app) => parseInt(app.jobId, 10));
        setAppliedJobs(appliedIds);
      })
      .catch((err) => console.error("Erreur récupération candidatures :", err));
  }, [user.id, user.token]);

  // Filtrage
  useEffect(() => {
    let results = [...jobs];
    if (searchWhat) {
      results = results.filter(
        (job) =>
          job.title?.toLowerCase().includes(searchWhat.toLowerCase()) ||
          job.company?.toLowerCase().includes(searchWhat.toLowerCase())
      );
    }
    if (searchWhere) {
      results = results.filter((job) =>
        job.location?.toLowerCase().includes(searchWhere.toLowerCase())
      );
    }
    if (!showAllJobs) {
      if (recommendedJobs.length > 0) {
        const recommendedIds = recommendedJobs.map((match) =>
          parseInt(match.jobId, 10)
        );
        results = results.filter((job) =>
          recommendedIds.includes(parseInt(job.id, 10))
        );
      } else {
        results = [];
      }
    }
    setFilteredJobs(results);
  }, [searchWhat, searchWhere, showAllJobs, jobs, recommendedJobs]);

  return (
    <div className="max-w-screen-xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Bienvenue, {user.name}</h2>

      {/* Barre de recherche */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <input
          type="text"
          placeholder="Intitulé de poste ou mots-clés"
          value={searchWhat}
          onChange={(e) => setSearchWhat(e.target.value)}
          className="border px-3 py-2 rounded w-full md:w-1/3"
        />
        <input
          type="text"
          placeholder="Ville ou région"
          value={searchWhere}
          onChange={(e) => setSearchWhere(e.target.value)}
          className="border px-3 py-2 rounded w-full md:w-1/3"
        />
        <button
          onClick={() => {}}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Rechercher
        </button>
      </div>

      {/* Toggle */}
      <div className="flex items-center gap-2 mb-6">
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={showAllJobs}
            onChange={(e) => setShowAllJobs(e.target.checked)}
            className="w-4 h-4"
          />
          <span>Afficher toutes les offres</span>
        </label>
      </div>

      {/* Liste des offres */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredJobs.length > 0 ? (
          filteredJobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              alreadyApplied={appliedJobs.includes(parseInt(job.id, 10))}
              user={user} /* Transmet l'objet user à JobCard */
            />
          ))
        ) : (
          <p className="text-gray-500">
            Aucune offre ne correspond à votre recherche.
          </p>
        )}
      </div>
    </div>
  );
};

export default CandidateDashboard;
