// JobSearchBar.jsx
import { useState } from "react";
import { FaFilter } from "react-icons/fa";

const JobSearchBar = ({ onSearch }) => {
  // Champs simples (like Indeed)
  const [what, setWhat] = useState("");
  const [where, setWhere] = useState("");

  // État pour le panneau de filtres avancés
  const [showFilters, setShowFilters] = useState(false);

  // Filtres avancés
  const [salaryMin, setSalaryMin] = useState("");
  const [salaryMax, setSalaryMax] = useState("");
  const [useMatching, setUseMatching] = useState(false);
  const [useRecommendations, setUseRecommendations] = useState(false);

  // Appelée quand on clique sur "Rechercher" ou "Appliquer"
  const handleSearch = () => {
    onSearch({
      what,
      where,
      salaryMin,
      salaryMax,
      useMatching,
      useRecommendations,
    });
  };

  return (
    <div className="w-full flex flex-col gap-2 md:gap-4">
      {/* Barre de recherche principale */}
      <div className="flex flex-col md:flex-row items-center gap-2">
        <input
          type="text"
          placeholder="What (ex: Développeur, React, Node...)"
          value={what}
          onChange={(e) => setWhat(e.target.value)}
          className="border px-3 py-2 rounded w-full md:w-1/3"
        />
        <input
          type="text"
          placeholder="Where (ex: Paris, Douala, etc.)"
          value={where}
          onChange={(e) => setWhere(e.target.value)}
          className="border px-3 py-2 rounded w-full md:w-1/3"
        />
        <button
          onClick={handleSearch}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Rechercher
        </button>

        {/* Icône pour afficher/masquer les filtres avancés */}
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center justify-center bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-2 rounded"
        >
          <FaFilter />
        </button>
      </div>

      {/* Panneau de filtres avancés (affiché si showFilters = true) */}
      {showFilters && (
        <div className="border p-4 rounded bg-gray-50 flex flex-col md:flex-row md:items-center gap-4">
          {/* Salaire min / max */}
          <input
            type="number"
            placeholder="Salaire min"
            value={salaryMin}
            onChange={(e) => setSalaryMin(e.target.value)}
            className="border px-3 py-2 rounded w-full md:w-1/6"
          />
          <input
            type="number"
            placeholder="Salaire max"
            value={salaryMax}
            onChange={(e) => setSalaryMax(e.target.value)}
            className="border px-3 py-2 rounded w-full md:w-1/6"
          />

          {/* Matching */}
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={useMatching}
              onChange={(e) => setUseMatching(e.target.checked)}
            />
            🔥 Matching IA
          </label>

          {/* Recommandations */}
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={useRecommendations}
              onChange={(e) => setUseRecommendations(e.target.checked)}
            />
            ⭐ Recommandations
          </label>

          {/* Bouton pour appliquer ces filtres */}
          <button
            onClick={handleSearch}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            Appliquer
          </button>
        </div>
      )}
    </div>
  );
};

export default JobSearchBar;
