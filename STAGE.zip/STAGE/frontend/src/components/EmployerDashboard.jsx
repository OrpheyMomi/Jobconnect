// 📄 src/components/EmployerDashboard.jsx
import { useEffect, useState } from "react";
import axios from "axios";

const EmployerDashboard = ({ user }) => {
  const [jobs, setJobs] = useState([]);
  const [jobCandidates, setJobCandidates] = useState([]);
  const [loading, setLoading] = useState(true);

  // 🔹 Étape 1 : Récupérer les offres d’emploi de l’employeur
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const res = await axios.get("http://127.0.0.1:5002/api/jobs", {
          headers: { Authorization: `Bearer ${user.token}` },
        });
        const employerJobs = res.data.jobs.filter(
          (job) => job.employerId === user.id
        );
        setJobs(employerJobs);
      } catch (err) {
        console.error("Erreur chargement jobs :", err);
      }
    };
    fetchJobs();
  }, [user.id, user.token]);

  // 🔹 Étape 2 : Pour chaque offre, récupérer les recommandations
  useEffect(() => {
    const fetchCandidatesForJobs = async () => {
      try {
        const allCandidates = [];

        for (const job of jobs) {
          try {
            const res = await axios.get(
              `http://127.0.0.1:5004/api/recommendations/employer/${job.id}`,
              { headers: { Authorization: `Bearer ${user.token}` } }
            );

            allCandidates.push({
              job,
              candidates: res.data.matches || [],
            });
          } catch (err) {
            console.error(`Erreur pour job ${job.id} :`, err);
            allCandidates.push({ job, candidates: [] });
          }
        }

        setJobCandidates(allCandidates);
        setLoading(false);
      } catch (err) {
        console.error("Erreur récupération candidats :", err);
        setLoading(false);
      }
    };

    if (jobs.length > 0) {
      fetchCandidatesForJobs();
    } else {
      setLoading(false);
    }
  }, [jobs, user.token]);

  if (loading) return <div className="p-6">Chargement...</div>;

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold">
        🏢 Bonjour, {user.companyName || user.name}
      </h2>
      <h3 className="mt-4 text-xl">📌 Offres et candidats recommandés</h3>

      {jobs.length === 0 ? (
        <p className="mt-4">Vous n'avez pas encore posté d'offres.</p>
      ) : (
        jobCandidates.map(({ job, candidates }) => (
          <div key={job.id} className="mt-6 bg-white p-4 rounded shadow">
            <h4 className="text-xl font-semibold">
              Offre : {job.title} ({job.location})
            </h4>
            <p className="text-gray-700 mb-2">{job.description}</p>
            {candidates && candidates.length > 0 ? (
              <div className="mt-2">
                <h5 className="font-semibold">Candidats recommandés :</h5>
                <ul className="mt-2 space-y-2">
                  {candidates.map((c, i) => (
                    <li
                      key={`${job.id}-${c.candidateId}-${i}`}
                      className="p-3 border bg-gray-50 rounded flex justify-between items-center"
                    >
                      <span>
                        Candidat #{c.candidateId} — Score : {c.score.toFixed(2)}
                      </span>
                      <button className="text-blue-500 hover:underline">
                        Voir le profil
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <p className="text-sm text-gray-500 mt-2">
                Aucun candidat recommandé pour cette offre.
              </p>
            )}
          </div>
        ))
      )}
    </div>
  );
};

export default EmployerDashboard;
