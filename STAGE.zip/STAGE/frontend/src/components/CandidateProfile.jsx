// src/components/CandidateProfile.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "./AuthContext"; // Ajustez le chemin si nécessaire

const CandidateProfile = () => {
  const { user, loading } = useAuth();
  const [profile, setProfile] = useState(null);

  // Pour la partie CV
  const [resume, setResume] = useState(null); // On stocke directement l'objet complet {id, title, description, fileUrl, ...}
  const [editing, setEditing] = useState(false);

  // État pour le formulaire d'édition du profil
  const [form, setForm] = useState({ name: "", email: "", bio: "" });

  useEffect(() => {
    if (!user) return;

    // 1. Récupération du profil via /api/auth/profile
    axios
      .get("http://127.0.0.1:5001/api/auth/profile", {
        headers: { Authorization: `Bearer ${user.token}` },
      })
      .then((res) => {
        // res.data = { message, user: {...} }
        const profileData = res.data.user;
        setProfile(profileData);
        setForm({
          name: profileData.name || "",
          email: profileData.email || "",
          bio: profileData.bio || "",
        });
      })
      .catch((err) => {
        console.error("Erreur chargement profil :", err);
      });

    // 2. Récupération du CV via /api/resumes/my-resumes
    axios
      .get("http://127.0.0.1:5003/api/resumes/my-resumes", {
        headers: { Authorization: `Bearer ${user.token}` },
      })
      .then((res) => {
        // res.data = { total, resumes: [...] }
        if (res.data.resumes && res.data.resumes.length > 0) {
          setResume(res.data.resumes[0]); // On prend le premier CV du tableau
        } else {
          setResume(null);
        }
      })
      .catch((err) => {
        console.error("Erreur chargement CV :", err);
        setResume(null);
      });
  }, [user]);

  const handleInputChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Mise à jour du profil
  const handleSave = () => {
    axios
      .put(`http://127.0.0.1:5001/api/profile/${user.id}`, form, {
        headers: { Authorization: `Bearer ${user.token}` },
      })
      .then((res) => {
        // res.data = { message, user: {...} }
        setProfile(res.data.user);
        setEditing(false);
      })
      .catch((err) => console.error("Erreur mise à jour profil :", err));
  };

  if (loading) return <div className="p-6">Chargement du profil...</div>;
  if (!user) return <div className="p-6">Utilisateur non connecté.</div>;

  // Si on n'a pas encore récupéré le profil
  if (!profile) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-bold">Mon Profil</h2>
        <p>Profil non trouvé ou en cours de chargement...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
      {/* ----- Profil ----- */}
      <h2 className="text-3xl font-bold mb-4">Mon Profil</h2>
      {editing ? (
        <div className="space-y-4">
          <div>
            <label className="block font-medium">Nom :</label>
            <input
              name="name"
              value={form.name}
              onChange={handleInputChange}
              className="border rounded px-3 py-2 w-full"
            />
          </div>
          <div>
            <label className="block font-medium">Email :</label>
            <input
              name="email"
              value={form.email}
              onChange={handleInputChange}
              className="border rounded px-3 py-2 w-full"
            />
          </div>
          <div>
            <label className="block font-medium">Bio :</label>
            <textarea
              name="bio"
              value={form.bio}
              onChange={handleInputChange}
              className="border rounded px-3 py-2 w-full"
              rows={4}
            />
          </div>
          <button
            onClick={handleSave}
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Enregistrer
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <p>
            <span className="font-medium">Nom :</span> {profile.name}
          </p>
          <p>
            <span className="font-medium">Email :</span> {profile.email}
          </p>
          <p>
            <span className="font-medium">Bio :</span> {profile.bio}
          </p>
          <button
            onClick={() => setEditing(true)}
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Modifier le profil
          </button>
        </div>
      )}

      {/* ----- CV ----- */}
      <div className="mt-6">
        <h3 className="text-2xl font-bold mb-2">Mon CV</h3>
        {resume ? (
          <div className="border p-4 rounded space-y-3">
            {/* Titre du CV */}
            <div>
              <p className="font-medium text-lg">Titre :</p>
              <p className="text-gray-700">{resume.title}</p>
            </div>

            {/* Description */}
            <div>
              <p className="font-medium text-lg">Description :</p>
              <p className="text-gray-700 whitespace-pre-line">
                {resume.description}
              </p>
            </div>

            {/* Skills */}
            {resume.skills && resume.skills.length > 0 && (
              <div>
                <p className="font-medium text-lg">Compétences :</p>
                <ul className="list-disc list-inside text-gray-700">
                  {resume.skills.map((skill, idx) => (
                    <li key={idx}>{skill}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Expérience */}
            {resume.experience !== undefined && (
              <div>
                <p className="font-medium text-lg">Expérience (en années) :</p>
                <p className="text-gray-700">{resume.experience}</p>
              </div>
            )}

            {/* Éducation */}
            {resume.education && (
              <div>
                <p className="font-medium text-lg">Éducation :</p>
                <p className="text-gray-700">{resume.education}</p>
              </div>
            )}

            {/* Statut */}
            {resume.status && (
              <div>
                <p className="font-medium text-lg">Statut :</p>
                <p className="text-gray-700">{resume.status}</p>
              </div>
            )}

            {/* Lien vers le PDF si fileUrl est défini */}
            {resume.fileUrl && (
              <div>
                <p className="font-medium text-lg">Fichier PDF :</p>
                <a
                  href={`http://127.0.0.1:5003${resume.fileUrl}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 underline"
                >
                  Voir le CV PDF
                </a>
              </div>
            )}
          </div>
        ) : (
          <div className="border p-4 rounded">
            <p>Aucun CV uploadé.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CandidateProfile;
