// src/utils/authUtils.js

export const SOME_CONSTANT = "valeur";

// Exemple de fonction utilitaire
export const formatUserName = (user) => {
  return `${user.firstName} ${user.lastName}`;
};
