// src/pages/Dashboard.jsx
import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";
import CandidateDashboard from "../components/CandidateDashboard";
import EmployerDashboard from "../components/EmployerDashboard";

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          console.error("❌ Aucun token trouvé, redirection vers Login");
          window.location.href = "/login";
          return;
        }
        const response = await axios.get("http://127.0.0.1:5001/api/auth/me", {
          headers: { Authorization: `Bearer ${token}` },
        });
        console.log("✅ Utilisateur récupéré :", response.data);
        setUser({ ...response.data, token });
      } catch (error) {
        console.error("❌ Erreur récupération utilisateur :", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  if (loading) return <div className="text-center p-10">Chargement...</div>;
  if (!user)
    return (
      <div className="text-center p-10 text-red-500">Erreur de connexion</div>
    );

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="ml-64 flex-1 flex flex-col">
        <Header user={user} />
        <main className="flex-1 p-6 bg-gray-100">
          {user.role === "candidate" ? (
            <CandidateDashboard user={user} />
          ) : (
            <EmployerDashboard user={user} />
          )}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
