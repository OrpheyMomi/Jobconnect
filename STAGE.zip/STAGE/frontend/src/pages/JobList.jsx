import { useEffect, useState } from "react";
import axios from "axios";
import JobCard from "../components/JobCard";

const JobList = ({ user }) => {
  const [jobs, setJobs] = useState([]); // Tous les jobs
  const [filteredJobs, setFilteredJobs] = useState([]); // Jobs après filtrage
  const [search, setSearch] = useState("");
  const [location, setLocation] = useState("");
  const [salaryMin, setSalaryMin] = useState("");
  const [salaryMax, setSalaryMax] = useState("");
  const [showMatching, setShowMatching] = useState(false);
  const [matches, setMatches] = useState([]);

  // ✅ Récupérer les jobs dès le chargement
  useEffect(() => {
    axios
      .get("http://127.0.0.1:5002/api/jobs")
      .then((res) => {
        setJobs(res.data);
        setFilteredJobs(res.data); // Initialiser l'affichage avec tous les jobs
      })
      .catch((err) => console.error("❌ Erreur récupération offres :", err));

    // ✅ Si l'utilisateur est un candidat, récupérer les matchings
    if (user.role === "candidate") {
      axios
        .get(`http://127.0.0.1:5004/api/recommendations/candidate/${user.id}`)
        // .get("http://127.0.0.1:5002/api/jobs")
        .then((res) => setMatches(res.data.matches))
        .catch((err) =>
          console.error("❌ Erreur récupération matchings :", err)
        );
    }
  }, [user.id, user.role]);

  // ✅ Appliquer les filtres en temps réel
  useEffect(() => {
    let filtered = jobs;

    if (search) {
      filtered = filtered.filter(
        (job) =>
          job.title.toLowerCase().includes(search.toLowerCase()) ||
          job.company.toLowerCase().includes(search.toLowerCase()) ||
          job.location.toLowerCase().includes(search.toLowerCase())
      );
    }

    if (location) {
      filtered = filtered.filter((job) =>
        job.location.toLowerCase().includes(location.toLowerCase())
      );
    }

    if (salaryMin) {
      filtered = filtered.filter((job) => job.salary >= parseInt(salaryMin));
    }

    if (salaryMax) {
      filtered = filtered.filter((job) => job.salary <= parseInt(salaryMax));
    }

    if (showMatching && matches.length > 0) {
      const matchingJobIds = matches.map((match) => match.jobId);
      filtered = filtered.filter((job) => matchingJobIds.includes(job.id));
      filtered.sort((a, b) => {
        const scoreA =
          matches.find((match) => match.jobId === a.id)?.score || 0;
        const scoreB =
          matches.find((match) => match.jobId === b.id)?.score || 0;
        return scoreB - scoreA; // Trier par score décroissant
      });
    }

    setFilteredJobs(filtered);
  }, [search, location, salaryMin, salaryMax, showMatching, jobs, matches]);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold">📋 Liste des Offres</h2>

      {/* 🔍 Barre de recherche */}
      <div className="mt-4 flex flex-wrap gap-3">
        <input
          type="text"
          placeholder="🔎 Rechercher un job ou entreprise..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border px-3 py-2 rounded w-full md:w-1/3"
        />
        <input
          type="text"
          placeholder="📍 Ville..."
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="border px-3 py-2 rounded w-full md:w-1/4"
        />
        <input
          type="number"
          placeholder="💰 Salaire min..."
          value={salaryMin}
          onChange={(e) => setSalaryMin(e.target.value)}
          className="border px-3 py-2 rounded w-full md:w-1/6"
        />
        <input
          type="number"
          placeholder="💰 Salaire max..."
          value={salaryMax}
          onChange={(e) => setSalaryMax(e.target.value)}
          className="border px-3 py-2 rounded w-full md:w-1/6"
        />
        {user.role === "candidate" && (
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={showMatching}
              onChange={(e) => setShowMatching(e.target.checked)}
              className="w-4 h-4"
            />
            🔥 Jobs avec Matching
          </label>
        )}
      </div>

      {/* 📌 Liste des jobs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        {filteredJobs.length > 0 ? (
          filteredJobs.map((job) => <JobCard key={job.id} job={job} />)
        ) : (
          <p className="text-gray-500">
            ❌ Aucun job ne correspond aux critères.
          </p>
        )}
      </div>
    </div>
  );
};

export default JobList;
