import { useEffect, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import axios from "axios";

const JobDetails = () => {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const { state } = useLocation();
  const user = state?.user; // Récupère l'objet user transmis via navigation, ou adapter si besoin

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);

  // Options pour le CV et la lettre
  const [cvOption, setCvOption] = useState("existing"); // "existing", "generate", "upload"
  const [uploadedCV, setUploadedCV] = useState(null); // Fichier sélectionné
  const [generatedCVText, setGeneratedCVText] = useState(""); // Contenu CV généré

  const [letterOption, setLetterOption] = useState("generate"); // "generate" ou "custom"
  const [customLetter, setCustomLetter] = useState("");
  const [generatedLetterText, setGeneratedLetterText] = useState(""); // Contenu Lettre générée

  useEffect(() => {
    axios
      .get(`http://127.0.0.1:5002/api/jobs/${jobId}`)
      .then((res) => {
        setJob(res.data);
      })
      .catch((err) => console.error("Erreur chargement job :", err))
      .finally(() => setLoading(false));
  }, [jobId]);

  // Fonction utilitaire pour convertir un fichier en Base64
  const fileToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  };

  // 1) Générer un nouveau CV AVANT postuler
  const handleGenerateCV = async () => {
    try {
      if (!job) {
        alert("Aucune offre chargée pour générer le CV");
        return;
      }
      // Appel au service personnalisation
      // On suppose qu’on a besoin du `resume.description` + `job.title` en param.
      // S’il n’y a pas de “CV existant” local, on fait juste un exemple :
      const payload = {
        cv_text: "Mon CV de base ou description existante", // Ajuste selon la logique
        job_title: job.title,
      };
      const response = await axios.post(
        "http://127.0.0.1:5005/api/personalization/cv",
        payload
      );
      const personalized =
        response.data.personalized_cv || "CV généré (fictif)";
      setGeneratedCVText(personalized);
      alert("CV généré avec succès !");
    } catch (error) {
      console.error("Erreur lors de la génération du CV :", error);
      alert("Impossible de générer le CV.");
    }
  };

  // 2) Générer une nouvelle lettre AVANT postuler
  const handleGenerateLetter = async () => {
    try {
      if (!job) {
        alert("Aucune offre chargée pour générer la lettre");
        return;
      }
      const payload = {
        cv_text: generatedCVText || "Mon CV existant si besoin",
        job_title: job.title,
      };
      const response = await axios.post(
        "http://127.0.0.1:5005/api/personalization/letter",
        payload
      );
      const letter =
        response.data.motivation_letter || "Lettre générée (fictive)";
      setGeneratedLetterText(letter);
      alert("Lettre de motivation générée avec succès !");
    } catch (error) {
      console.error("Erreur lors de la génération de la lettre :", error);
      alert("Impossible de générer la lettre.");
    }
  };

  // 3) Au moment de postuler (après éventuellement avoir généré le CV / la lettre)
  const handleApply = async () => {
    try {
      let custom_cv = "";
      if (cvOption === "existing") {
        custom_cv = ""; // Laisser le backend utiliser le CV existant
      } else if (cvOption === "generate") {
        // On utilise le CV généré
        if (!generatedCVText) {
          alert("Vous avez choisi de générer un CV mais il n’est pas généré !");
          return;
        }
        custom_cv = generatedCVText;
      } else if (cvOption === "upload") {
        if (!uploadedCV) {
          alert("Veuillez sélectionner un fichier CV.");
          return;
        }
        // Convertir le fichier en base64
        custom_cv = await fileToBase64(uploadedCV);
      }

      let custom_letter = "";
      if (letterOption === "generate") {
        // On utilise la lettre générée
        if (!generatedLetterText) {
          alert(
            "Vous avez choisi de générer une lettre mais elle n’est pas générée !"
          );
          return;
        }
        custom_letter = generatedLetterText;
      } else {
        // letterOption === "custom"
        custom_letter = customLetter;
      }

      const payload = { custom_cv, custom_letter };
      await axios.post(
        `http://127.0.0.1:5002/api/jobs/${jobId}/apply`,
        payload,
        { headers: { Authorization: `Bearer ${user.token}` } }
      );
      alert("Candidature envoyée avec succès !");
      navigate("/dashboard");
    } catch (error) {
      console.error(
        "Erreur lors de la candidature :",
        error.response?.data || error
      );
      alert("Erreur lors de la candidature. Veuillez réessayer.");
    }
  };

  if (loading) return <div className="text-center p-6">Chargement...</div>;
  if (!job) return <div className="text-center p-6">Offre introuvable.</div>;

  return (
    <div>
      <header className="p-4 flex justify-between items-center bg-white shadow">
        <h1 className="text-xl font-bold">{job.title}</h1>
        <div>
          Bonjour, {user?.name || "Invité"} |
          <button
            onClick={() => {
              localStorage.removeItem("token");
              window.location.href = "/login";
            }}
            className="ml-4 text-blue-500"
          >
            Déconnexion
          </button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto p-6">
        <h2 className="text-3xl font-bold mb-4">{job.title}</h2>
        <p className="text-gray-800 font-medium mb-2">
          {job.company} – {job.location}
        </p>
        <p className="text-gray-600 mb-4">{job.description}</p>
        {job.salary !== undefined && (
          <p className="text-green-600 font-semibold mb-4">
            Salaire : {job.salary.toLocaleString()} € / an
          </p>
        )}

        {/* Formulaire de candidature */}
        <div className="border-t pt-4">
          <h3 className="text-xl font-semibold mb-2">Postuler à cette offre</h3>

          {/* Choix du CV */}
          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Choix du CV
            </label>
            <div className="flex flex-col gap-2">
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="cvOption"
                  value="existing"
                  checked={cvOption === "existing"}
                  onChange={() => setCvOption("existing")}
                />
                Utiliser le CV existant
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="cvOption"
                  value="generate"
                  checked={cvOption === "generate"}
                  onChange={() => setCvOption("generate")}
                />
                Générer un nouveau CV
                {cvOption === "generate" && (
                  <button
                    type="button"
                    onClick={handleGenerateCV}
                    className="ml-2 px-3 py-1 bg-blue-500 text-white rounded text-sm"
                  >
                    Générer
                  </button>
                )}
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="cvOption"
                  value="upload"
                  checked={cvOption === "upload"}
                  onChange={() => setCvOption("upload")}
                />
                Uploader un nouveau CV
              </label>
              {cvOption === "upload" && (
                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={(e) => {
                    const file = e.target.files[0];
                    setUploadedCV(file);
                  }}
                  className="border rounded px-3 py-2"
                />
              )}
            </div>

            {/* Prévisualisation du CV généré (si l’utilisateur a généré) */}
            {cvOption === "generate" && generatedCVText && (
              <div className="mt-2 p-2 border rounded bg-gray-50 text-sm">
                <h4 className="font-semibold">Aperçu du CV généré :</h4>
                <pre>{generatedCVText}</pre>
              </div>
            )}
          </div>

          {/* Choix de la lettre */}
          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Choix de la lettre
            </label>
            <div className="flex flex-col gap-2">
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="letterOption"
                  value="generate"
                  checked={letterOption === "generate"}
                  onChange={() => setLetterOption("generate")}
                />
                Générer une nouvelle lettre
                {letterOption === "generate" && (
                  <button
                    type="button"
                    onClick={handleGenerateLetter}
                    className="ml-2 px-3 py-1 bg-blue-500 text-white rounded text-sm"
                  >
                    Générer
                  </button>
                )}
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="letterOption"
                  value="custom"
                  checked={letterOption === "custom"}
                  onChange={() => setLetterOption("custom")}
                />
                Saisir une lettre personnalisée
              </label>
              {letterOption === "custom" && (
                <textarea
                  placeholder="Votre lettre de motivation"
                  value={customLetter}
                  onChange={(e) => setCustomLetter(e.target.value)}
                  className="border rounded px-3 py-2"
                  rows={4}
                />
              )}
            </div>

            {/* Prévisualisation de la lettre générée (si l’utilisateur a généré) */}
            {letterOption === "generate" && generatedLetterText && (
              <div className="mt-2 p-2 border rounded bg-gray-50 text-sm">
                <h4 className="font-semibold">Aperçu de la lettre générée :</h4>
                <pre>{generatedLetterText}</pre>
              </div>
            )}
          </div>

          <button
            onClick={handleApply}
            className="mt-4 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 w-full sm:w-auto transition duration-300"
          >
            Postuler maintenant
          </button>
        </div>
      </main>
    </div>
  );
};

export default JobDetails;
