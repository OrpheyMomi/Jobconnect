import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "candidate", // Par défaut
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setUserData({ ...userData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (userData.password !== userData.confirmPassword) {
      setError("Les mots de passe ne correspondent pas !");
      return;
    }

    try {
      const response = await axios.post(
        "http://127.0.0.1:5001/api/auth/register",
        userData
      );
      console.log("✅ Inscription réussie :", response.data);
      navigate("/login"); // Rediriger vers la connexion après inscription
    } catch (err) {
      console.error(
        "❌ Erreur d'inscription :",
        err.response?.data || err.message
      );
      setError(err.response?.data?.message || "Une erreur s'est produite.");
    }
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <form
        onSubmit={handleSubmit}
        className="bg-white p-8 rounded-lg shadow-md w-96"
      >
        <h2 className="text-2xl font-bold text-center mb-4">Inscription</h2>

        {error && <p className="text-red-500 text-sm text-center">{error}</p>}

        <input
          type="text"
          name="name"
          placeholder="Nom"
          value={userData.name}
          onChange={handleChange}
          className="w-full p-2 border border-gray-300 rounded mb-3"
          required
        />

        <input
          type="email"
          name="email"
          placeholder="Email"
          value={userData.email}
          onChange={handleChange}
          className="w-full p-2 border border-gray-300 rounded mb-3"
          required
        />

        <input
          type="password"
          name="password"
          placeholder="Mot de passe"
          value={userData.password}
          onChange={handleChange}
          className="w-full p-2 border border-gray-300 rounded mb-3"
          required
        />

        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirmez le mot de passe"
          value={userData.confirmPassword}
          onChange={handleChange}
          className="w-full p-2 border border-gray-300 rounded mb-3"
          required
        />

        <select
          name="role"
          value={userData.role}
          onChange={handleChange}
          className="w-full p-2 border border-gray-300 rounded mb-3"
        >
          <option value="candidate">Candidat</option>
          <option value="employer">Employeur</option>
        </select>

        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-700"
        >
          S'inscrire
        </button>

        <p className="text-sm text-center mt-3">
          Déjà un compte ?{" "}
          <a href="/login" className="text-blue-500">
            Se connecter
          </a>
        </p>
      </form>
    </div>
  );
};

export default Register;
