const API_BASE_URL = "http://127.0.0.1:5001/api"; // Remplace par l'URL de ton backend auth-service

export { API_BASE_URL };
