// src/App.jsx
import { Routes, Route } from "react-router-dom";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import Dashboard from "./pages/Dashboard";
import JobDetails from "./pages/JobDetails";
import CandidateProfile from "./components/CandidateProfile";
import CandidateApplications from "./components/CandidateApplications";
import Notifications from "./components/Notifications";
import { AuthProvider } from "./components/AuthContext";
import Header from "./components/Header";

const App = () => {
  return (
    <AuthProvider>
      <Routes>
        {/* Pour les pages avec header statique */}
        <Route path="/dashboard" element={<Dashboard />} />
        <Route
          path="/profile"
          element={
            <>
              <Header />
              <CandidateProfile />
            </>
          }
        />
        <Route
          path="/applications"
          element={
            <>
              <Header />
              <CandidateApplications />
            </>
          }
        />
        <Route
          path="/notifications"
          element={
            <>
              <Header />
              <Notifications />
            </>
          }
        />
        <Route path="/jobs/:jobId" element={<JobDetails />} />

        {/* Routes sans header */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        {/* Autres routes... */}
      </Routes>
    </AuthProvider>
  );
};

export default App;
