from fastapi import APIRouter
from app.services.cv_generator import personalize_cv
from app.services.motivation_letter_generator import generate_motivation_letter

router = APIRouter()

@router.post("/cv")
def generate_personalized_cv(cv_data: dict):
    """Personnalise un CV en fonction de l'offre d'emploi"""
    personalized_cv = personalize_cv(cv_data)
    return {"personalized_cv": personalized_cv}

@router.post("/letter")
def generate_letter(letter_data: dict):
    """Génère une lettre de motivation personnalisée"""
    motivation_letter = generate_motivation_letter(letter_data)
    return {"motivation_letter": motivation_letter}
