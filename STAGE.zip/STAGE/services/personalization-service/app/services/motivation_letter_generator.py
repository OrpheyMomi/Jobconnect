import openai
import os
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("La variable d'environnement OPENAI_API_KEY n'est pas définie.")
openai.api_key = api_key

def generate_motivation_letter(letter_data):
    """Génère une lettre de motivation avec GPT-4"""
    prompt = f"""
    Génère une lettre de motivation professionnelle pour un poste de {letter_data['job_title']} en utilisant ce CV :
    {letter_data['cv_text']}
    """

    response = openai.ChatCompletion.create(
    model="gpt-4o-mini",
    messages=[{"role": "system", "content": "Tu es un assistant spécialisé en recrutement."},
              {"role": "user", "content": prompt}]
              )

    return response["choices"][0]["message"]["content"]