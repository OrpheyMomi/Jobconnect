# def personalize_cv(cv_data):
#     """Modifie le CV en fonction de l'offre d'emploi"""
#     cv_text = cv_data["cv_text"]
#     job_description = cv_data["job_description"]

#     # 🚀 IA simplifiée : Ajoute une section "Adapté pour ce poste"
#     personalized_section = f"\n### Pourquoi ce CV est adapté ?\n{job_description}"
    
#     return cv_text + personalized_section
def personalize_cv(cv_data):
    # Utiliser get() permet d'éviter une KeyError si une clé est manquante
    cv_text = cv_data.get("cv_text", "")
    job_title = cv_data.get("job_title", "")
    
    # Exemple de traitement : personnaliser le CV en fonction du titre du poste
    personalized_cv = f"CV personnalisé pour le poste de {job_title}:\n{cv_text}"
    
    return personalized_cv

