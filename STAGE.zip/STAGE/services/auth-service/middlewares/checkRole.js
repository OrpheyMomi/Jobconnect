// const checkRole = (allowedRoles) => {
//   return (req, res, next) => {
//     console.log("🚀 Middleware `checkRole` exécuté !");
//     console.log("👤 Utilisateur connecté :", req.user);
//     console.log("🎯 Rôles autorisés :", allowedRoles);
//     if (!req.user || !allowedRoles.includes(req.user.role)) {
//       return res
//         .status(403)
//         .json({ message: "Accès refusé. Rôle insuffisant." });
//     }
//     next();
//   };
// };

// module.exports = checkRole;

const checkRole = (allowedRoles) => {
  return (req, res, next) => {
    console.log("🚀 Middleware `checkRole` exécuté !");
    console.log("👤 Utilisateur connecté :", req.user);
    console.log("🎯 Rôles autorisés :", allowedRoles);

    if (!req.user) {
      console.error("❌ Erreur : req.user est indéfini !");
      return res
        .status(403)
        .json({ message: "Accès refusé. Utilisateur non trouvé." });
    }

    if (!allowedRoles.includes(req.user.role)) {
      console.error("⛔ Accès refusé. Rôle insuffisant :", req.user.role);
      return res
        .status(403)
        .json({ message: "Accès refusé. Rôle insuffisant." });
    }

    console.log("✅ Rôle valide, accès autorisé !");
    next();
  };
};

module.exports = checkRole;
