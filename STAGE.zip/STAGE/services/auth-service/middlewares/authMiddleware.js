// const jwt = require("jsonwebtoken");

// const verifyToken = (req, res, next) => {
//   const authHeader = req.headers.authorization;

//   // Vérifie si le token est fourni
//   if (!authHeader || !authHeader.startsWith("Bearer ")) {
//     return res
//       .status(401)
//       .json({ message: "Accès refusé. Aucun token fourni." });
//   }

//   const token = authHeader.split(" ")[1]; // Récupère uniquement le token

//   try {
//     // Vérifie le token avec la clé secrète
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded; // Stocke les infos du token dans req.user
//     next(); // Passe à la suite
//   } catch (error) {
//     return res.status(403).json({ message: "Token invalide." });
//   }
// };

// module.exports = verifyToken;

const jwt = require("jsonwebtoken");

const verifyToken = (req, res, next) => {
  console.log("🚀 Middleware `verifyToken` exécuté !");
  console.log("📢 Requête reçue avec headers :", req.headers);

  const authHeader = req.headers.authorization;

  // Vérifie si le token est fourni
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    console.log("❌ Aucun token fourni !");
    return res
      .status(401)
      .json({ message: "Accès refusé. Aucun token fourni." });
  }

  const token = authHeader.split(" ")[1]; // Récupère uniquement le token

  try {
    // Vérifie le token avec la clé secrète
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log("✅ Token valide !", decoded);

    req.user = decoded; // Stocke les infos du token dans req.user
    next(); // Passe à la suite
  } catch (error) {
    console.log("❌ Token invalide :", error.message);
    return res.status(403).json({ message: "Token invalide." });
  }
};

console.log("🔑 JWT_SECRET chargé :", process.env.JWT_SECRET);

module.exports = verifyToken;
