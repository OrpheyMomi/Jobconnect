// userRoutes.js
const express = require("express");
const router = express.Router();
const {
  registerUser,
  loginUser,
  updateProfile,
  deleteAccount,
  forgotPassword,
  resetPassword,
  getProfile,
  getMe,
} = require("../controllers/authController");
const verifyToken = require("../middlewares/authMiddleware");
const checkRole = require("../middlewares/checkRole");

router.post("/register", registerUser);
router.post("/login", loginUser);

router.put("/update-profile", verifyToken, updateProfile);
router.delete("/delete-account", verifyToken, deleteAccount);
router.post("/forgot-password", forgotPassword);
router.post("/reset-password/:token", resetPassword);

// Les routes pour récupérer les informations de l'utilisateur connecté
router.get("/profile", verifyToken, getProfile);
router.get("/me", verifyToken, getMe);

// Routes pour les dashboards en fonction des rôles
router.get(
  "/employer-dashboard",
  verifyToken,
  checkRole(["employer"]),
  (req, res) => {
    res.json({
      message: "Bienvenue sur le tableau de bord Employeur",
      user: req.user,
    });
  }
);

router.get(
  "/candidate-dashboard",
  verifyToken,
  checkRole(["candidate"]),
  (req, res) => {
    res.json({
      message: "Bienvenue sur le tableau de bord Candidat",
      user: req.user,
    });
  }
);

router.get("/admin", verifyToken, checkRole(["admin"]), (req, res) => {
  res.json({ message: "Bienvenue sur la page Admin", user: req.user });
});

module.exports = router;
