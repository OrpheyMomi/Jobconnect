const { Sequelize } = require("sequelize");
require("dotenv").config({ path: "../../env/.env.database" });

// require("dotenv").config({ path: __dirname + "/../../env/.env.database" });

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: "postgres",
    port: process.env.DB_PORT,
    logging: false, // Désactiver les logs SQL
  }
);

// Vérifier la connexion
(async () => {
  try {
    await sequelize.authenticate();
    console.log("✅ Connexion à PostgreSQL réussie.");
  } catch (error) {
    console.error("❌ Erreur de connexion à PostgreSQL :", error);
  }
})();

module.exports = sequelize;
