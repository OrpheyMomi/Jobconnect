require("dotenv").config({ path: "../../env/.env.auth" });
const express = require("express");
const app = express();
const userRoutes = require("./routes/userRoutes");
const sequelize = require("./config/database");
const cors = require("cors");

app.use(express.json());

app.use(cors({ origin: "http://localhost:5173", credentials: true }));

// Routes API
app.use("/api/auth", userRoutes);

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Auth service running on port ${PORT}`);
});

(async () => {
  try {
    await sequelize.sync({ alter: true }); // Crée les tables si elles n'existent pas
    console.log("✅ Synchronisation de la base de données réussie.");
  } catch (error) {
    console.error(
      "❌ Erreur lors de la synchronisation de la base de données :",
      error
    );
  }
})();
