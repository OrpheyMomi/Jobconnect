const nodemailer = require("nodemailer");
const config = require("../config/config");

const transporter = nodemailer.createTransport({
  host: config.email.host,
  port: config.email.port,
  auth: {
    user: config.email.user,
    pass: config.email.pass,
  },
});

const sendEmail = async (to, subject, text) => {
  try {
    await transporter.sendMail({ from: config.email.user, to, subject, text });
    console.log(`📧 E-mail envoyé à ${to}`);
  } catch (error) {
    console.error("❌ Erreur d'envoi d'e-mail :", error);
  }
};

module.exports = { sendEmail };
