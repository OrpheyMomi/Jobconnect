const WebSocket = require("ws");
const config = require("../config/config");

const wss = new WebSocket.Server({ port: config.websocket.port });

const clients = new Map();

wss.on("connection", (ws, req) => {
  const userId = req.url.split("=")[1]; // Récupérer l'ID utilisateur
  clients.set(userId, ws);
  console.log(`🔌 WebSocket connecté pour utilisateur ${userId}`);

  ws.on("close", () => {
    clients.delete(userId);
  });
});

const sendNotification = (userId, message) => {
  const client = clients.get(userId);
  if (client) {
    client.send(JSON.stringify({ message }));
  }
};

module.exports = { sendNotification };
