const mongoose = require("mongoose");

const NotificationSchema = new mongoose.Schema(
  {
    userId: { type: Number, required: true },
    message: { type: String, required: true },
    type: {
      type: String,
      enum: ["candidature", "statut", "matching"],
      required: true,
    }, // ✅ Ajout de "matching"
    isRead: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now },
  },
  { collection: "notifications" }
);

module.exports = mongoose.model("Notification", NotificationSchema);
