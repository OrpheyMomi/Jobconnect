require("dotenv").config();
const express = require("express");
const db = require("./config/database"); // Connexion MongoDB
const notificationRoutes = require("./routes/notificationRoutes");
const cors = require("cors");

const app = express();
app.use(express.json());

// Appliquer CORS avant de définir les routes
app.use(
  cors({
    origin: "http://localhost:5173",
    methods: "GET,POST,PUT,DELETE",
    allowedHeaders: "Content-Type,Authorization",
    credentials: true,
  })
);

// 📌 Routes API
app.use("/api/notifications", notificationRoutes);

const PORT = process.env.PORT || 5007;
app.listen(PORT, () =>
  console.log(`🚀 Notification Service lancé sur le port ${PORT}`)
);
