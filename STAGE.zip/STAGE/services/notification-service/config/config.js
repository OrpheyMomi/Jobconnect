module.exports = {
  email: {
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: process.env.SMTP_PORT || 587,
    user: process.env.SMTP_USER || "orpheymomi@gmail.com",
    pass: process.env.SMTP_PASS || "momi1999",
  },
  websocket: {
    port: process.env.WEBSOCKET_PORT || 5006,
  },
};
