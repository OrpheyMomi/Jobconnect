const Notification = require("../models/Notification");
const { sendEmail } = require("../services/emailService");
const { sendNotification } = require("../services/socketService");

const createNotification = async (req, res) => {
  try {
    const { userId, message, type, email } = req.body;

    // Enregistrer dans MongoDB
    const notification = new Notification({ userId, message, type });
    await notification.save();

    // Envoyer un e-mail
    if (email) {
      await sendEmail(email, "Nouvelle Notification", message);
    }

    // Envoyer via WebSocket
    sendNotification(userId, message);

    res.status(201).json({ message: "Notification envoyée", notification });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

const getUserNotifications = async (req, res) => {
  try {
    const { userId } = req.params;
    const notifications = await Notification.find({ userId }).sort(
      "-createdAt"
    );
    res.status(200).json({ notifications });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

module.exports = { createNotification, getUserNotifications };
