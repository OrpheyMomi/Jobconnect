const express = require("express");
const {
  createNotification,
  getUserNotifications,
} = require("../controllers/notificationController");

const router = express.Router();

// 📌 Route pour créer une notification
router.post("/", createNotification);

// 📌 Route pour récupérer les notifications d'un utilisateur
router.get("/:userId", getUserNotifications);

module.exports = router;
