const { Op } = require("sequelize");
const Resume = require("../models/Resume");
const User = require("../../auth-service/models/User");
const fs = require("fs");

// 📌 Ajouter un CV
const createResume = async (req, res) => {
  try {
    let { title, description, skills, experience, education, status } =
      req.body;
    const userId = req.user.id;
    const fileUrl = req.file ? `/uploads/${req.file.filename}` : null;

    if (!fileUrl) {
      return res
        .status(400)
        .json({ message: "Le fichier PDF est obligatoire." });
    }

    if (typeof skills === "string") {
      try {
        skills = JSON.parse(skills); // ✅ Si envoyé comme `["JS","Node"]`, le convertir
      } catch (e) {
        skills = skills.split(",").map((skill) => skill.trim()); // ✅ Sinon, séparer par virgule
      }
    }

    const resume = await Resume.create({
      userId,
      title,
      description,
      fileUrl,
      skills: Array.isArray(skills) ? skills : [], // ✅ Empêche l'erreur `map is not a function`
      experience,
      education,
      status: status || "private",
    });

    res.status(201).json({ message: "CV ajouté avec succès", resume });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error: error.message });
  }
};

// 📌 Récupérer tous les CVs visibles
const getAllResumes = async (req, res) => {
  try {
    const resumes = await Resume.findAll({ where: { status: "public" } });

    if (!resumes.length) {
      return res.status(404).json({ message: "Aucun CV trouvé." });
    }

    res.status(200).json({ total: resumes.length, resumes });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error: error.message });
  }
};

// 📌 Récupérer les CVs d’un utilisateur
const getUserResumes = async (req, res) => {
  try {
    const userId = req.user.id;
    const resumes = await Resume.findAll({ where: { userId } });

    if (!resumes.length) {
      return res.status(404).json({ message: "Aucun CV trouvé." });
    }

    res.status(200).json({ total: resumes.length, resumes });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error: error.message });
  }
};

const updateResume = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, skills, experience, education, status } =
      req.body;
    const resume = await Resume.findByPk(id);

    if (!resume) return res.status(404).json({ message: "CV non trouvé." });

    // Vérifier si l'utilisateur est l'auteur ou admin
    if (resume.userId !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Accès interdit." });
    }

    // Mise à jour du fichier si un nouveau fichier est envoyé
    let fileUrl = resume.fileUrl;
    if (req.file) {
      // Supprimer l'ancien fichier si nécessaire
      if (resume.fileUrl) fs.unlinkSync("." + resume.fileUrl);

      fileUrl = `/uploads/${req.file.filename}`;
    }

    await resume.update({
      title,
      description,
      fileUrl,
      skills,
      experience,
      education,
      status,
    });

    res.status(200).json({ message: "CV mis à jour avec succès", resume });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error: error.message });
  }
};

// 📌 Supprimer un CV
const deleteResume = async (req, res) => {
  try {
    const { id } = req.params;
    const resume = await Resume.findByPk(id);

    if (!resume) return res.status(404).json({ message: "CV non trouvé." });

    // Vérifier si l'utilisateur est l'auteur ou admin
    if (resume.userId !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Accès interdit." });
    }

    // Supprimer le fichier du serveur
    if (resume.fileUrl) fs.unlinkSync("." + resume.fileUrl);

    await resume.destroy();
    res.status(200).json({ message: "CV supprimé avec succès" });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error: error.message });
  }
};

module.exports = {
  createResume,
  getAllResumes,
  getUserResumes,
  updateResume,
  deleteResume,
};
