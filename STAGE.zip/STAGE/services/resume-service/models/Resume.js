const { DataTypes } = require("sequelize");
const sequelize = require("../../auth-service/config/database");

const Resume = sequelize.define("Resume", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Users",
      key: "id",
    },
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  fileUrl: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  skills: {
    type: DataTypes.ARRAY(DataTypes.STRING),
    allowNull: true,
  },
  experience: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  education: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM("public", "private"),
    defaultValue: "private",
  },
});

// 🔥 Importer `User.js` après la définition de `Resume`
const User = require("../../auth-service/models/User");

// 🔗 Définir l'association
Resume.belongsTo(User, { foreignKey: "userId", as: "user" });

console.log("🔍 Nom du modèle Sequelize :", Resume.getTableName());

module.exports = Resume;
