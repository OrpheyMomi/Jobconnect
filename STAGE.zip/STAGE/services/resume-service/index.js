const express = require("express");
const cors = require("cors");
const path = require("path");

require("dotenv").config();

const app = express();
app.use(express.json());
app.use(cors());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// 🔗 Importation des routes
const resumeRoutes = require("./routes/resumeRoutes");

// 📌 Définition des routes
app.use("/api/resumes", resumeRoutes);

app.use(
  cors({
    origin: "http://localhost:5173",
    methods: "GET,POST,PUT,DELETE",
    allowedHeaders: "Content-Type,Authorization",
  })
);

const sequelize = require("../auth-service/config/database");
sequelize
  .sync({ alter: true }) // 🔥 Change `force: true` si tu veux tout recréer
  .then(() => console.log("✅ Base de données mise à jour avec `resumes`"))
  .catch((err) => console.error("❌ Erreur Sequelize :", err));

// 📌 Lancer le serveur
const PORT = process.env.PORT || 5003;
app.listen(PORT, () => {
  console.log(`📢 Resume service running on port ${PORT}`);
});
