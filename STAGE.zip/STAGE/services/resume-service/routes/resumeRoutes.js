const express = require("express");
const router = express.Router();
const {
  createResume,
  getAllResumes,
  getUserResumes,
  updateResume,
  deleteResume,
} = require("../controllers/resumeController");
const verifyToken = require("../../auth-service/middlewares/authMiddleware");
const upload = require("../middlewares/uploadMiddleware");

// 📌 Créer un CV (🔒 Auth obligatoire)
router.post("/", verifyToken, upload.single("file"), createResume);

// 📌 Récupérer tous les CVs publics
router.get("/", getAllResumes);

// 📌 Récupérer les CVs de l'utilisateur connecté
router.get("/my-resumes", verifyToken, getUserResumes);

router.put("/:id", verifyToken, upload.single("file"), updateResume);

// 📌 Supprimer un CV
router.delete("/:id", verifyToken, deleteResume);

module.exports = router;
