const multer = require("multer");
const path = require("path");

// 📌 Configuration du stockage des fichiers
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // 📂 Dossier où les fichiers seront stockés
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${Math.round(
      Math.random() * 1e9
    )}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  },
});

// 📌 Filtrer les fichiers (seulement PDF autorisés)
const fileFilter = (req, file, cb) => {
  if (file.mimetype === "application/pdf") {
    cb(null, true);
  } else {
    cb(new Error("Seuls les fichiers PDF sont autorisés !"), false);
  }
};

// 📌 Middleware Multer
const upload = multer({ storage, fileFilter });

module.exports = upload;
