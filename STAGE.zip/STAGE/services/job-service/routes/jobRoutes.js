const express = require("express");
const router = express.Router();
const {
  createJob,
  getJobs,
  updateJob,
  deleteJob,
  getJobById,
  updateJobStatus,
  applyForJob,
  updateApplicationStatus,
  getAllApplications,
  getUserApplications,
} = require("../controllers/jobController");
const verifyToken = require("../../auth-service/middlewares/authMiddleware"); // Protéger les routes
const checkRole = require("../../auth-service/middlewares/checkRole");

// 📌 Route pour récupérer toutes les candidatures (Admin & Employer)
router.get(
  "/applications",
  verifyToken,
  checkRole(["admin", "employer"]),
  (req, res, next) => {
    console.log("📢 La requête arrive bien dans jobRoutes.js !");
    next();
  },
  getAllApplications
);
// 📌 Routes pour la gestion des offres d'emploi
router.post("/", verifyToken, checkRole(["admin", "employer"]), createJob); // Créer une offre
router.get("/", getJobs); // Récupérer toutes les offres
router.put("/:id", verifyToken, checkRole(["admin", "employer"]), updateJob); // Modifier une offre
router.delete("/:id", verifyToken, checkRole(["admin", "employer"]), deleteJob); // Supprimer une offre
router.get("/:id", getJobById); // Récupérer une offre spécifique

// 📌 Route pour postuler à une offre (Candidate uniquement)
router.post("/:id/apply", verifyToken, checkRole(["candidate"]), applyForJob);

// 📌 Route pour mettre à jour le statut d'une offre (Admin & Employer)
router.put(
  "/:id/status",
  verifyToken,
  checkRole(["admin", "employer"]),
  updateJobStatus
);

// 📌 Route pour mettre à jour le statut d'une candidature (Employer uniquement)
router.put(
  "/applications/:id/status",
  verifyToken,
  checkRole(["employer"]),
  updateApplicationStatus
);

// 📌 Route pour récupérer les candidatures d'un utilisateur spécifique (Candidate uniquement)
router.get(
  "/user/:id/applications",
  verifyToken,
  checkRole(["candidate"]),
  getUserApplications
);

console.log(
  "📌 Routes chargées :",
  router.stack.map((r) => r.route && r.route.path)
);

module.exports = router;
