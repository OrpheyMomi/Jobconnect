require("dotenv").config({ path: "../../env/.env.jobs" });
const express = require("express");
const app = express();
const jobRoutes = require("./routes/jobRoutes");
const sequelize = require("./config/database");
const db = require("./models");
const cors = require("cors");

app.use(express.json());
app.use(cors());

app.use(
  cors({
    origin: "http://localhost:5173", // Remplace par l'URL du frontend en production
    methods: "GET,POST,PUT,DELETE",
    allowedHeaders: "Content-Type,Authorization",
  })
);

app.use("/api/jobs", jobRoutes);
// Job.hasMany(Application, { foreignKey: "jobId", as: "applications" });
// Application.belongsTo(Job, { foreignKey: "jobId", as: "job" });

console.log("✅ jobRoutes.js chargé !");

app.use((req, res, next) => {
  console.log(`📢 Requête générale : ${req.method} ${req.originalUrl}`);
  next();
});

const PORT = process.env.PORT || 5002;

app.listen(PORT, async () => {
  console.log(`Job service running on port ${PORT}`);
  try {
    await sequelize.sync({ alter: true });
    console.log("✅ Synchronisation de la base de données réussie.");
  } catch (error) {
    console.error(
      "❌ Erreur lors de la synchronisation de la base de données :",
      error
    );
  }
});
