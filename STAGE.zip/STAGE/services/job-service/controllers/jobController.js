const { Op } = require("sequelize");
const Job = require("../models/Job");
const User = require("../../auth-service/models/User");
const Application = require("../models/Application");
const Resume = require("../../resume-service/models/Resume");
const axios = require("axios");

// 📌 Créer une offre d'emploi
const createJob = async (req, res) => {
  try {
    const { title, description, company, location, salary } = req.body;
    const employerId = req.user.id;
    const job = await Job.create({
      title,
      description,
      company,
      location,
      salary,
      employerId,
    });
    res.status(201).json(job);
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

// 📌 Récupérer toutes les offres d'emploi
const getJobs = async (req, res) => {
  try {
    const {
      location,
      minSalary,
      maxSalary,
      keyword,
      page = 1,
      limit = 10,
    } = req.query;
    const offset = (page - 1) * limit; // Détermine où commencer la récupération

    let filters = {};

    if (location) {
      filters.location = { [Op.iLike]: `%${location}%` };
    }

    if (minSalary && maxSalary) {
      filters.salary = { [Op.between]: [minSalary, maxSalary] };
    } else if (minSalary) {
      filters.salary = { [Op.gte]: minSalary };
    } else if (maxSalary) {
      filters.salary = { [Op.lte]: maxSalary };
    }

    if (keyword) {
      filters[Op.or] = [
        { title: { [Op.iLike]: `%${keyword}%` } },
        { company: { [Op.iLike]: `%${keyword}%` } },
      ];
    }

    const { count, rows: jobs } = await Job.findAndCountAll({
      where: filters,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [["createdAt", "DESC"]],
    });

    res.json({
      totalJobs: count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page),
      jobs,
    });
  } catch (error) {
    console.error("Erreur lors de la récupération des offres :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
};

// 📌 Mettre à jour une offre d'emploi
const updateJob = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, company, location, salary } = req.body;
    const job = await Job.findByPk(id);
    if (!job) return res.status(404).json({ message: "Offre non trouvée" });

    await job.update({ title, description, company, location, salary });
    res.json(job);
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

// 📌 Supprimer une offre d'emploi
const deleteJob = async (req, res) => {
  try {
    const { id } = req.params;
    const job = await Job.findByPk(id);
    if (!job) return res.status(404).json({ message: "Offre non trouvée" });

    await job.destroy();
    res.json({ message: "Offre supprimée avec succès" });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

const getJobById = async (req, res) => {
  try {
    const job = await Job.findByPk(req.params.id);
    if (!job) {
      return res.status(404).json({ message: "Offre non trouvée" });
    }
    res.json(job);
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur" });
  }
};

const updateJobStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const job = await Job.findByPk(req.params.id);
    if (!job) {
      return res.status(404).json({ message: "Offre non trouvée" });
    }
    job.status = status;
    await job.save();
    res.json({ message: "Statut mis à jour", job });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur" });
  }
};

// Fonction d'application avec notifications
const applyForJob = async (req, res) => {
  try {
    const { id: jobId } = req.params;
    const { id: userId } = req.user;
    const { custom_cv, custom_letter } = req.body; // CV et Lettre fournis par le candidat

    // Vérifier si l'offre existe
    const job = await Job.findByPk(jobId);
    if (!job) {
      return res.status(404).json({ message: "Offre non trouvée" });
    }

    // Vérifier si le candidat a un CV
    const resume = await Resume.findOne({ where: { userId } });
    if (!resume) {
      return res
        .status(400)
        .json({ message: "Aucun CV trouvé. Veuillez en ajouter un." });
    }

    let finalCvText = custom_cv || resume.description;
    let finalLetterText = custom_letter || null;

    // Génération d'un CV personnalisé si nécessaire
    if (!custom_cv) {
      try {
        const response = await axios.post(
          "http://127.0.0.1:5005/api/personalization/cv",
          { cv_text: resume.description, job_title: job.title }
        );
        finalCvText = response.data.personalized_cv || resume.description;
      } catch (error) {
        console.error(
          "❌ Erreur lors de la personnalisation du CV :",
          error.message
        );
      }
    }

    // Génération d'une lettre de motivation si nécessaire
    if (!custom_letter) {
      try {
        const response = await axios.post(
          "http://127.0.0.1:5005/api/personalization/letter",
          { cv_text: finalCvText, job_title: job.title }
        );
        finalLetterText = response.data.motivation_letter || null;
      } catch (error) {
        console.error(
          "❌ Erreur lors de la génération de la lettre :",
          error.message
        );
      }
    }

    // Vérifier si le candidat a déjà postulé
    const existingApplication = await Application.findOne({
      where: { jobId, userId },
    });
    if (existingApplication) {
      return res
        .status(400)
        .json({ message: "Vous avez déjà postulé à cette offre." });
    }

    // Créer la candidature
    const application = await Application.create({
      jobId,
      userId,
      personalized_cv: finalCvText,
      personalized_letter: finalLetterText,
    });

    // Envoyer une notification à l'employeur
    const employer = await User.findByPk(job.employerId);
    if (employer) {
      try {
        await axios.post("http://127.0.0.1:5007/api/notifications", {
          userId: job.employerId,
          message: `Nouvelle candidature pour ${job.title}`,
          type: "candidature",
          email: employer.email,
        });
      } catch (notificationError) {
        console.error(
          "❌ Erreur lors de l'envoi de la notification :",
          notificationError.message
        );
      }
    }

    res.status(201).json({
      message: "Candidature envoyée avec succès",
      application,
    });
  } catch (error) {
    console.error("❌ Erreur dans applyForJob :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
};

const updateApplicationStatus = async (req, res) => {
  try {
    const { id: applicationId } = req.params;
    const { status, message } = req.body;

    if (!["invité à une entrevue", "non retenu"].includes(status)) {
      return res.status(400).json({ message: "Statut invalide." });
    }

    const application = await Application.findByPk(applicationId);
    if (!application) {
      return res.status(404).json({ message: "Candidature non trouvée." });
    }

    application.status = status;
    application.message =
      message ||
      (status === "invité à une entrevue"
        ? "Félicitations ! Nous aimerions vous rencontrer pour une entrevue."
        : "Merci pour votre candidature. Nous allons continuer avec d'autres candidats.");

    await application.save();

    res
      .status(200)
      .json({ message: "Candidature mise à jour avec succès", application });
  } catch (error) {
    console.error(
      "❌ Erreur lors de la mise à jour de la candidature :",
      error
    );
    res.status(500).json({ message: "Erreur serveur" });
  }
};

const getUserApplications = async (req, res) => {
  try {
    const { id: userId } = req.params;
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: "Utilisateur non trouvé." });
    }
    const applications = await Application.findAll({
      where: { userId },
      include: [
        {
          model: Job,
          as: "jobDetails",
          attributes: ["id", "title", "company", "location"],
        },
      ],
    });
    res.status(200).json({ applications });
  } catch (error) {
    console.error(
      "❌ Erreur lors de la récupération des candidatures :",
      error
    );
    res.status(500).json({ message: "Erreur serveur" });
  }
};

const getAllApplications = async (req, res) => {
  try {
    let applications;
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let queryOptions = {
      include: [
        {
          model: Job,
          as: "jobDetails",
          attributes: ["id", "title", "company", "location", "employerId"],
        },
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [["createdAt", "DESC"]],
    };

    if (req.user.role === "admin") {
      const { count, rows } = await Application.findAndCountAll(queryOptions);
      applications = rows;
      totalApplications = count;
    } else if (req.user.role === "employer") {
      queryOptions.include[0].where = { employerId: req.user.id };
      const { count, rows } = await Application.findAndCountAll(queryOptions);
      applications = rows;
      totalApplications = count;
    }

    if (!applications || applications.length === 0) {
      return res.status(404).json({ message: "Aucune candidature trouvée." });
    }

    res.status(200).json({
      totalApplications,
      totalPages: Math.ceil(totalApplications / limit),
      currentPage: parseInt(page),
      applications,
    });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error: error.message });
  }
};

module.exports = {
  createJob,
  getJobs,
  updateJob,
  deleteJob,
  getJobById,
  updateJobStatus,
  applyForJob,
  updateApplicationStatus,
  getUserApplications,
  getAllApplications,
};
