const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Application = sequelize.define("Application", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  jobId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM("en attente", "invité à une entrevue", "non retenu"),
    defaultValue: "en attente",
  },
  message: { type: DataTypes.TEXT, allowNull: true }, // ✅ Message personnalisé de l'employeur
});

module.exports = Application;
