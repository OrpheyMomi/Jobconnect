const sequelize = require("../config/database");
const Job = require("./Job");
const Application = require("./Application");

// ✅ Associations
Job.hasMany(Application, { foreignKey: "jobId", as: "jobApplications" });
Application.belongsTo(Job, { foreignKey: "jobId", as: "jobDetails" });

const db = { sequelize, Job, Application };

module.exports = db;
