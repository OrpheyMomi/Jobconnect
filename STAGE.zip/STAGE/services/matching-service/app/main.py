from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import matching_routes
from app.routes import recommendation_routes

app = FastAPI(title="Matching Service")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # L'URL de ton frontend React
    allow_credentials=True,
    allow_methods=["*"],  # Autoriser toutes les méthodes (GET, POST, PUT, DELETE)
    allow_headers=["*"],  # Autoriser tous les headers
)

app.include_router(matching_routes.router, prefix="/api")

app.include_router(recommendation_routes.router, prefix="/api")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, port=5004, reload=True)
