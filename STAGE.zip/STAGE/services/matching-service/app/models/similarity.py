import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from app.services.nlp_service import get_embedding

def compute_similarity(skills1, skills2):
    """Compute the cosine similarity between two sets of skills."""
    skills1 = np.array(skills1)
    skills2 = np.array(skills2)
    
    if skills1.size == 0 or skills2.size == 0:
        return 0.0


    emb1 = skills1.reshape(1,-1) if skills1.ndim == 1 else skills1
    emb2 = skills2.reshape(1,-1) if skills2.ndim == 1 else skills2
    
    emb1, emb2 = np.array(emb1).squeeze(), np.array(emb2).squeeze()
    if emb1.ndim == 1:
        emb1 = emb1.reshape(1, -1)  # ✅ Assure que c'est une matrice 2D
    if emb2.ndim == 1:
        emb2 = emb2.reshape(1, -1)
    return cosine_similarity(emb1, emb2)[0][0]
