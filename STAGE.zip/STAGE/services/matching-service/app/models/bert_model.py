# from transformers import pipeline

# nlp_pipeline = pipeline("feature-extraction", model="sentence-transformers/all-MiniLM-L6-v2")

# def get_embedding(text):
#     embeddings = nlp_pipeline(text)
#     print(f"🔍 Embeddings générés : {embeddings}")  # Débug

#     if not embeddings:
#         print(f"❌ Aucune embedding générée pour : {text}")
#         return None  # Retourne None pour éviter l'erreur

#     return embeddings[0]


from transformers import pipeline

nlp_pipeline = pipeline("feature-extraction", model="sentence-transformers/all-MiniLM-L6-v2")

def get_embedding(text):
    if isinstance(text, list):
        text = " ".join(text)

    # ✅ Tronquer le texte à environ 2000 caractères
    if len(text) > 2000:
        print(f"⚠️ Texte trop long ({len(text)} caractères), tronqué à 2000.")
        text = text[:2000]

    try:
        embeddings = nlp_pipeline(text)
        print(f"🔍 Embeddings générés : {embeddings[:1]}...")  # Pour éviter trop de log

        if not embeddings:
            print(f"❌ Aucune embedding générée pour : {text}")
            return None

        return embeddings[0]

    except Exception as e:
        print(f"❌ Erreur lors de la génération des embeddings : {e}")
        return None
