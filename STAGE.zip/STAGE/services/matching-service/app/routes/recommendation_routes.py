from fastapi import APIRouter, Header
import requests
import os

from app.services.resume_service import get_resumes, get_candidate_resume
from app.services.job_service import get_jobs
from app.services.pdf_service import extract_text_from_pdf, extract_skills_from_text
from app.models.similarity import compute_similarity
from app.models.bert_model import get_embedding

router = APIRouter()

NOTIFICATION_SERVICE_URL = "http://127.0.0.1:5007/api/notifications"

def send_notification(user_id, message, notif_type="matching"):
    """Envoie une notification au service de notifications"""
    if not user_id:
        print("⚠️ Impossible d'envoyer la notification, `user_id` est manquant.")
        return
    data = {
        "userId": user_id,
        "message": message,
        "type": notif_type
    }
    try:
        response = requests.post(NOTIFICATION_SERVICE_URL, json=data)
        response.raise_for_status()
        print(f"✅ Notification envoyée à {user_id} : {message}")
    except requests.exceptions.RequestException as e:
        print(f"❌ Erreur lors de l'envoi de la notification : {e}")

@router.get("/recommendations/candidate/{candidate_id}")
def recommend_jobs_for_candidate(candidate_id: int, authorization: str = Header(None)):
    """
    Recommande les meilleures offres pour un candidat, en se basant sur son CV
    et le contenu des offres récupérées depuis le service des jobs.
    """
    if not authorization:
        return {"error": "Token manquant"}

    print(f"🔑 Token reçu : {authorization}")

    # 1. Récupérer le CV du candidat
    resumes = get_resumes(authorization, is_employer=False)
    candidate = next((r for r in resumes if r["userId"] == candidate_id), None)
    if not candidate:
        print(f"❌ Aucun CV trouvé pour userId={candidate_id}")
        return {"error": "Candidat non trouvé"}

    print(f"✅ Candidat sélectionné : {candidate}")

    # 2. Extraire le texte du CV
    cv_text = get_candidate_resume(candidate)
    if not cv_text:
        return {"error": "Impossible de lire le CV"}

    # 3. Extraire les compétences du candidat
    candidate_skills = extract_skills_from_text(cv_text)
    print(f"📝 Compétences extraites du candidat : {candidate_skills}")

    # 4. Récupérer la liste des offres d'emploi
    jobs = get_jobs()
    if not jobs:
        return {"error": "Aucune offre d'emploi disponible"}

    # 5. Calculer la similarité avec chaque offre
    matches = []
    for job in jobs:
        # Extraire les compétences du job
        job_skills = extract_skills_from_text(job["description"])

        # Convertir en embeddings
        candidate_emb = get_embedding(candidate_skills)
        job_emb = get_embedding(job_skills)

        if not candidate_emb or not job_emb:
            print(f"❌ Embedding non trouvé pour candidat {candidate['userId']} ou job {job['id']}")
            continue

        # Score de similarité
        score = compute_similarity(candidate_emb, job_emb)
        print(f"🔹 Similarité avec {job['title']} (ID {job['id']}) : {score}")

        # Filtrer uniquement les offres pertinentes (score > 0.3 par exemple)
        if score > 0.75:
            matches.append({
                "jobId": job["id"],
                "title": job["title"],
                "score": score
            })

    # 6. Trier par score décroissant
    matches.sort(key=lambda x: x["score"], reverse=True)

    # 7. Envoyer une notification si on trouve au moins une offre pertinente
    if matches:
        send_notification(
            candidate_id,
            f"🔔 Une nouvelle offre ({matches[0]['title']}) correspond à votre profil !"
        )

    # 8. Retourner les offres triées par score
    return {"total": len(matches), "matches": matches}

@router.get("/recommendations/employer/{job_id}")
def recommend_candidates_for_job(job_id: int, authorization: str = Header(None)):
    """
    Recommande les candidats pour une offre d'emploi donnée (pour l'employeur).
    """
    if not authorization:
        return {"error": "Token manquant"}

    print(f"🔑 Token reçu : {authorization}")

    # 1. Récupérer l'offre d'emploi
    jobs = get_jobs()
    job = next((j for j in jobs if j["id"] == job_id), None)
    if not job:
        print(f"❌ Offre d'emploi introuvable pour id={job_id}")
        return {"error": "Job non trouvé"}

    print(f"✅ Offre sélectionnée : {job}")

    # 2. Récupérer les CVs des candidats
    resumes = get_resumes(authorization, is_employer=True)
    print(f"📄 CVs récupérés ({len(resumes)}): {resumes}")
    if not resumes:
        print("❌ Aucun CV trouvé")
        return {"error": "Aucun CV trouvé"}
    
    matches = []
    for r in resumes:
        cv_text = get_candidate_resume(r)
        if not cv_text:
            continue
        # Ici, on utilise le texte du CV pour créer l'embedding
        candidate_embedding = get_embedding(cv_text)
        job_embedding = get_embedding(job["description"])
        if not candidate_embedding or not job_embedding:
            print(f"❌ Embedding non trouvé pour candidat {r['userId']} ou job {job['id']}")
            continue

        score = compute_similarity(candidate_embedding, job_embedding)
        print(f"🔹 Similarité pour candidat {r['userId']} avec l'offre '{job['title']}': {score}")

        # On peut ajuster le seuil (ici 0.3)
        if score > 0.3:
            matches.append({
                "candidateId": r["userId"],
                "score": score
            })

    # 4. Trier les recommandations par score décroissant
    matches.sort(key=lambda x: x["score"], reverse=True)
    print(f"Total recommandations: {len(matches)}")
    return {"total": len(matches), "matches": matches}
