from fastapi import APIRouter, Depends, Header
from app.services.resume_service import get_resumes
from app.services.job_service import get_jobs
from app.models.similarity import compute_similarity
from app.services.pdf_service import extract_text_from_pdf,extract_skills_from_text
from app.services.resume_service import get_resumes, get_candidate_resume
from app.models.bert_model import get_embedding
import os

router = APIRouter()

@router.get("/matching/candidate/{candidate_id}")
def match_candidate(candidate_id: int, authorization: str = Header(None)):
    """Compare un candidat avec les offres d'emploi disponibles."""
    if not authorization:
        return {"error": "Token manquant"}

    print(f"🔑 Token reçu : {authorization}")

    resumes = get_resumes(authorization)
    candidate = next((r for r in resumes if r["userId"] == candidate_id), None)

    if not candidate:
        print(f"❌ Aucun CV trouvé pour userId={candidate_id}")
        return {"error": "Candidat non trouvé"}

    print(f"✅ Candidat sélectionné : {candidate}")

    # 📄 Lecture du CV PDF
    cv_text = get_candidate_resume(candidate)
    if not cv_text:
        return {"error": "Impossible de lire le CV"}

    print(f"📄 Texte extrait du CV : {cv_text[:500]}...")  # 🔥 Affiche seulement les 500 premiers caractères

    # 🔥 Extraction des compétences depuis le CV
    candidate_skills = extract_skills_from_text(cv_text)
    print(f"📝 Compétences extraites du candidat : {candidate_skills}")

    # 📌 Récupération des offres d'emploi
    jobs = get_jobs()
    if not jobs:
        return {"error": "Aucune offre d'emploi disponible"}

    matches = []
    for job in jobs:
        job_skills = extract_skills_from_text(job["description"])
        cand_emb = get_embedding(["description"])  # 🔄 Convertir le texte en vecteur
        job_emb = get_embedding(job["description"])
        print(f"🔍 Embedding candidat : {cand_emb[:5]}...")  # ✅ Vérifier les vecteurs
        print(f"🔍 Embedding job : {job_emb[:5]}...")
        # Calculer la similarité
        score = compute_similarity(cand_emb, job_emb)

        print(f"🔹 Similarité avec {job['title']} : {score}")

        if score > 0.3:  # Filtrer les jobs pertinents
            matches.append({"jobId": job["id"], "title": job["title"], "score": score})

    matches = sorted(matches, key=lambda x: x["score"], reverse=True)

    return {"total": len(matches), "matches": matches}
    if not authorization:
        return {"error": "Token manquant"}

    print(f"🔑 Token reçu : {authorization}")

    resumes = get_resumes(authorization)
    candidate = next((r for r in resumes if r["userId"] == candidate_id), None)

    if not candidate:
        return {"error": "Candidat non trouvé"}
    
    print(f"✅ Candidat sélectionné : {candidate}")

    # 🔥 Lire le CV PDF si disponible
    candidate_text = candidate["description"]  # Par défaut, on prend la description
    if "fileUrl" in candidate and candidate["fileUrl"]:
        pdf_path = os.path.join(UPLOADS_FOLDER, os.path.basename(candidate["fileUrl"]))
        print(f"🔍 Vérification du chemin PDF : {pdf_path}")
        if os.path.exists(pdf_path):
            extracted_text = extract_text_from_pdf(pdf_path)
            if extracted_text:
                candidate_text = extracted_text
                print(f"📄 Texte extrait du CV : {candidate_text[:300]}...")  # 🔹 Afficher un aperçu du texte
        else:
            print(f"❌ Fichier PDF introuvable : {pdf_path}")

    jobs = get_jobs()
    if not jobs:
        return {"error": "Aucune offre d'emploi disponible"}

    # 🏆 Matching NLP basé sur le texte extrait
    matches = [{"jobId": job["id"], "title": job["title"], "score": compute_similarity(candidate_text, job["description"])}
               for job in jobs]

    matches = sorted(matches, key=lambda x: x["score"], reverse=True)
    return {"total": len(matches), "matches": matches}

# @router.get("/matching/candidate/{candidate_id}")
# def match_candidate(candidate_id: int, authorization: str = Header(None)):
    """Compare un candidat avec les offres d'emploi disponibles en utilisant NLP avancé."""
    if not authorization:
        return {"error": "Token manquant"}

    print(f"🔑 Token reçu : {authorization}")

    resumes = get_resumes(authorization)
    print(f"📌 CVs récupérés ({len(resumes)}) : {resumes}")

    candidate = next((r for r in resumes if r["userId"] == candidate_id), None)
    if not candidate:
        print(f"❌ Aucun CV trouvé pour userId={candidate_id}")
        return {"error": "Candidat non trouvé"}

    print(f"✅ Candidat sélectionné : {candidate}")

    jobs = get_jobs()
    if not jobs:
        return {"error": "Aucune offre d'emploi disponible"}

    # 🏆 Matching avec NLP avancé (BERT)
    matches = []
    for job in jobs:
        score = compute_similarity(candidate["description"], job["description"])

        print(f"📝 Job : {job['title']} | Score Similarité : {score}")

        if score > 0.4:  # Seulement les jobs ayant un score > 30%
            matches.append({"jobId": job["id"], "title": job["title"], "score": score})

    matches = sorted(matches, key=lambda x: x["score"], reverse=True)

    return {"total": len(matches), "matches": matches}
    if not authorization:
        return {"error": "Token manquant"}
    
    print(f"🔑 Token reçu : {authorization}")

    resumes = get_resumes(authorization)
    print(f"📌 CVs récupérés ({len(resumes)}) : {resumes}") 
    candidate = next((r for r in resumes if r["userId"] == candidate_id), None)

    if not candidate:
        print(f"❌ Aucun CV trouvé pour userId={candidate_id}")
        return {"error": "Candidat non trouvé"}
    
    print(f"✅ Candidat sélectionné : {candidate}")

    jobs = get_jobs()
    matches = [{"jobId": job["id"], "score": compute_similarity(candidate["description"], job["description"])}
               for job in jobs]

    matches = sorted(matches, key=lambda x: x["score"], reverse=True)
    return {"total": len(matches), "matches": matches}


@router.get("/matching/job/{job_id}")
def match_job(job_id: int, authorization: str = Header(None)):
    if not authorization:
        return {"error": "Token manquant"}
    
    print(f"🔑 Token reçu : {authorization}")

    jobs = get_jobs()
    job = next((j for j in jobs if j["id"] == job_id), None)

    if not job:
        print(f"❌ Job introuvable pour id={job_id}")
        return {"error": "Job non trouvé"}
    
    print(f"✅ Job sélectionné : {job}")

    resumes = get_resumes(authorization)
    matches = [[{
    "candidateId": r["userId"], 
    "score": compute_similarity(
        get_embedding(r["description"]), 
        get_embedding(job["description"])
        )}]
    for r in resumes ]

    matches = sorted(matches, key=lambda x: x["score"], reverse=True)
    return {"total": len(matches), "matches": matches}
