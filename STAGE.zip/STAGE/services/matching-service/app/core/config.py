import os

RESUME_SERVICE_URL = os.getenv("RESUME_SERVICE_URL", "http://localhost:5003/api/resumes")
JOB_SERVICE_URL = os.getenv("JOB_SERVICE_URL", "http://localhost:5002/api")
