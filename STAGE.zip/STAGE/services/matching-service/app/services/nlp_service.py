# import requests
import spacy
from transformers import pipeline
import numpy as np

nlp = spacy.load("fr_core_news_lg")
nlp_pipeline = pipeline("feature-extraction", model="sentence-transformers/all-MiniLM-L6-v2")

# NLP_SERVICE_URL = "http://127.0.0.1:8000/extract-skills"  # 🔥 Assure-toi que ton NLP Service tourne ici !

def extract_skills_from_text(text):
    """Extract numerical embeddings for skills from text."""
    if not text:
        return np.zeros((384,))  # Return a zero vector if text is empty
    embeddings = np.array(nlp_pipeline(text))  # Convert list to np.array
    return np.mean(embeddings, axis=0)  # Average across sentences if needed


def get_embedding(text):
    """Transforme un texte en vecteur avec un modèle BERT."""
    if not text:
        return np.zeros((384,))  # Taille du vecteur pour ce modèle
    embeddings = np.array(nlp_pipeline(text))
    return np.mean(embeddings, axis=0)  # Moyenne des embeddings