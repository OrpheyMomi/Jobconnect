import fitz  # PyMuPDF
from transformers import pipeline
import os

# Chargement du modèle NLP pour extraire les compétences (NER)
ner_pipeline = pipeline("ner", model="dbmdz/bert-large-cased-finetuned-conll03-english")


BASE_DIR = os.path.abspath(os.path.dirname(__file__))  
UPLOADS_FOLDER = os.path.abspath(os.path.join(BASE_DIR, "../../../resume-service/uploads"))

def extract_text_from_pdf(pdf_path):
    """Extrait le texte d'un fichier PDF"""
    text = ""
    try:
        with fitz.open(pdf_path) as doc:
            for page in doc:
                text += page.get_text("text") + "\n"
        return text.strip()
    except Exception as e:
        print(f"❌ Erreur lecture PDF {pdf_path} : {e}")
        return None

# def extract_text_from_pdf(pdf_path):
    """Lit un fichier PDF et extrait le texte brut."""
    text = ""
    try:
        with fitz.open(pdf_path) as doc:
            for page in doc:
                text += page.get_text("text") + "\n"
        return text.strip()
    except Exception as e:
        print(f"❌ Erreur lors de la lecture du PDF : {e}")
        return ""

def extract_skills_from_text(text):
    """Utilise un modèle NLP pour détecter les compétences dans le texte."""
    if not text:
        return []

    skills = set()
    entities = ner_pipeline(text)
    
    for entity in entities:
        if entity["entity"].startswith("B-") or entity["entity"].startswith("I-"):
            skills.add(entity["word"])
    
    return list(skills)
