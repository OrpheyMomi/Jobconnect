import requests
from app.core.config import JOB_SERVICE_URL

def get_jobs():
    response = requests.get(f"{JOB_SERVICE_URL}/jobs")
    return response.json().get("jobs", []) if response.status_code == 200 else []
