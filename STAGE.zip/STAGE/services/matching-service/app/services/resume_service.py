import requests
import fitz  # PyMuPDF pour lire les PDF
import os
from app.core.config import RESUME_SERVICE_URL

# Compute the absolute path to the resume-service/uploads directory
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))
UPLOADS_DIR = os.path.join(BASE_DIR, "resume-service", "uploads")
print(f"UPLOADS_DIR: {UPLOADS_DIR}")  # Debug: Vérifier le chemin absolu

def get_resumes(token: str, is_employer: bool = False):
    """Récupère les CVs d'un utilisateur depuis le resume-service.
       Utilise l'endpoint '/api/resumes' si is_employer est True,
       sinon utilise '/api/resumes/my-resumes'.
    """
    headers = {"Authorization": token}
    endpoint = "" if is_employer else "/my-resumes"
    try:
        response = requests.get(f"{RESUME_SERVICE_URL}{endpoint}", headers=headers)
        response.raise_for_status()
        data = response.json()
        print(f"📤 Résumés récupérés : {data}")  # Vérifie la réponse
        return data.get("resumes", [])
    except requests.exceptions.RequestException as e:
        print(f"❌ Erreur récupération des CVs : {e}")
        return []

def read_pdf_text(pdf_path):
    """Extrait le texte brut d'un fichier PDF."""
    text = ""
    try:
        with fitz.open(pdf_path) as doc:
            for page in doc:
                text += page.get_text("text") + "\n"
        return text.strip()
    except Exception as e:
        print(f"❌ Erreur lors de la lecture du PDF : {e}")
        return None

def get_candidate_resume(candidate):
    """Récupère et analyse le CV PDF d'un candidat."""
    file_path = os.path.join(UPLOADS_DIR, os.path.basename(candidate["fileUrl"]))
    print(f"🔍 Vérification du chemin PDF : {file_path}")
    if not os.path.exists(file_path):
        print(f"❌ Fichier PDF introuvable : {file_path}")
        return None
    return read_pdf_text(file_path)
